using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneToBo : MonoBehaviour

{
    private float elapsedTime = 0f;
    public string nextSceneName = "YourNextSceneName"; // ใส่ชื่อฉากที่ต้องการโหลดต่อไปที่นี่

    void Update()
    {
        // เพิ่มเวลาที่ผ่านไปตลอดเวลา
        elapsedTime += Time.deltaTime;

        
        if (elapsedTime >= 0.1f)
        {
            
            LoadNextScene();
        }
    }

    void LoadNextScene()
    {
        // โหลดฉาก
        UnityEngine.SceneManagement.SceneManager.LoadScene(nextSceneName);
    }
}