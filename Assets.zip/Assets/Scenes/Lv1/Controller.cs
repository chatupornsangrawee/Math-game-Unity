using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
 
    // ระบุ GameObject ที่มีชื่อ "oop1"
    public GameObject oop1;

    // ระบุ GameObject ที่มีชื่อ "oop2"
    public GameObject oop2;

    // ระบุ GameObject ที่มีชื่อ "oop3"
    public GameObject oop3;

    void Update()
    {
    {
            // ตรวจสอบว่ามีวัตถุ "oop1" อยู่ในฉากหรือไม่
            if (oop1 != null && oop1.activeSelf)
            {
                // เปิดใช้งานวัตถุ "oop2"
                oop2.SetActive(true);

                // ทำลายวัตถุ "oop3"
                Destroy(oop3);
            }
            else
            {
                // ถ้าไม่พบวัตถุ "oop1" ในฉาก
                Debug.LogError("ไม่พบวัตถุที่ชื่อ oop1 ในฉาก");
            }
        }
    }


}