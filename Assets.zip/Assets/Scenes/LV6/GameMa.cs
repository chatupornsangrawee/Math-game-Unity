using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameMa : MonoBehaviour
{
    public string objectNameToCheck = "false";
    public string levelToLoad = "Lv6";
    private bool loaded = false;
    private float startTime;

    void Start()
    {
        startTime = Time.realtimeSinceStartup;
    }

    void Update()
    {
        StartCoroutine(CheckForObjectAndLoadLevel());
    }

    IEnumerator CheckForObjectAndLoadLevel()
    {
        yield return new WaitForSeconds(3f); // Wait for 3 seconds

        GameObject objectToCheck = GameObject.Find(objectNameToCheck);

        if (objectToCheck != null)
        {
            Debug.Log("Found object with name: " + objectNameToCheck);
            LoadLevel(levelToLoad);
        }

        float elapsedTime = Time.realtimeSinceStartup - startTime;
        if (!loaded && elapsedTime > 13f)
        {
            loaded = true;
            startTime = Time.realtimeSinceStartup; // รีเซ็ตเวลา
            LoadLevel(levelToLoad);
        }
    }

    void LoadLevel(string levelName)
    {
        // Load the scene with the given levelName
        SceneManager.LoadScene(levelName);
    }
}
