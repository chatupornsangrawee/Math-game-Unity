using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ObjectBehavior : MonoBehaviour
{
    private float timer = 0f;
    private float switchSceneInterval = 2f;
    private int totalScenes = 50;
    private int currentScene = 1;

    void Update()
    {
        // เพิ่มเวลาที่ผ่านไปตลอดเวลา
        timer += Time.deltaTime;

        // ตรวจสอบว่าเวลาผ่านไปหลังจาก 2 วินาทีหรือไม่
        if (timer >= switchSceneInterval)
        {
            // รีเซ็ตตัวนับเวลา
            timer = 0f;

            // เปลี่ยนฉาก
            SwitchToNextScene();
        }
    }

    void SwitchToNextScene()
    {
        // ตรวจสอบว่ายังมีฉากต่อไปหรือไม่
        if (currentScene <= totalScenes)
        {
            // สุ่มฉากต่อไป
            int nextScene = Random.Range(1, totalScenes + 1);

            // แสดงชื่อฉากที่สุ่มได้ (ในกรณีนี้ให้ใช้ Debug.Log)
            Debug.Log("Switching to Scene " + nextScene);

            // โหลดฉากที่สุ่มได้
            SceneManager.LoadScene(nextScene.ToString());

            // เพิ่มตัวแปร currentScene เพื่อเก็บค่าฉากปัจจุบัน
            currentScene++;
        }
    }
}